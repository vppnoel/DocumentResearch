# Workflow de production documentaire assistée par IA — V0.1 (adaptation opérationnelle)

## 1. Statut du document

Le présent document décrit une **adaptation opérationnelle** du workflow de production documentaire assistée par intelligence artificielle.

Il :
- n’introduit aucune règle nouvelle,
- ne modifie ni le cadre normatif V0 ni la doctrine V0,
- explicite un usage **réaliste, quotidien et multi-environnement** de l’IA.

Le cadre de référence demeure :
- `01_cadre_fige/cadre_sources_V0.html`
- `04_gouvernance/doctrine_et_usages.md`

---

## 2. Principe directeur

> La production est humaine.  
> L’IA est une assistance ponctuelle.  
> La responsabilité est intégrale.

L’IA n’est pas une étape autonome du workflow,  
mais un **outil mobilisable localement**, sous conditions strictes.

---

## 3. Structure générale du workflow (adapté)

Le workflow repose sur **trois blocs stables**, avec des **boucles contrôlées** :

1. Qualification des sources (verrouillée)
2. Production humaine avec assistance IA ponctuelle
3. Intégration, contrôle et validation humaine

Aucun bloc ne peut être supprimé ou fusionné.

---

## 4. Bloc 1 — Qualification des sources (inchangé, normatif)

### 4.1 Statut

Bloc **préalable obligatoire** et **verrouillé**.

### 4.2 Règles

- Toutes les sources sont qualifiées selon le cadre V0.
- Les niveaux de preuve, priorités et usages possibles sont fixés.
- Aucune IA n’intervient à ce stade.

### 4.3 Résultat attendu

- Registre de sources qualifiées
- Identifiants de sources utilisables (Sxx)
- Version du cadre explicitement référencée (V0)

---

## 5. Bloc 2 — Production humaine avec assistance IA ponctuelle

### 5.1 Principe

La rédaction et l’argumentation sont **construites par l’auteur**.

L’IA peut être utilisée **ponctuellement**, sur des segments limités,
pour assister la formulation, la clarté ou la structure locale.

---

### 5.2 Usages autorisés de l’IA

L’IA peut être utilisée pour :

- reformuler un paragraphe déjà rédigé,
- améliorer la lisibilité académique,
- clarifier une phrase ou un raisonnement existant,
- proposer une structuration locale (titres, transitions),
- vérifier la cohérence logique interne d’un passage.

---

### 5.3 Usages interdits de l’IA

L’IA ne peut en aucun cas :

- sélectionner ou proposer des sources,
- qualifier une source ou modifier son statut,
- produire un raisonnement scientifique autonome,
- tirer des conclusions,
- décider de l’architecture globale du document.

---

### 5.4 Conditions d’appel à l’IA

Tout usage de l’IA doit être encadré par :

- la référence explicite au cadre utilisé (V0),
- la liste des sources autorisées (IDs),
- l’objectif précis de l’intervention (ex. reformulation),
- l’interdiction d’ajout de contenu non fourni.

#### Exemple d’appel conforme

> Travail dans le cadre V0.  
> Sources autorisées : S03, S07.  
> Objectif : reformulation académique neutre du paragraphe ci-dessous.  
> Aucun ajout de source ni d’argument.

---

## 6. Bloc 3 — Intégration, contrôle et validation humaine

### 6.1 Intégration

Tout apport issu de l’IA est :

- relu de manière critique,
- intégré ou réécrit par l’auteur,
- assumé pleinement comme contenu propre.

Aucun passage n’est conservé sans appropriation humaine.

---

### 6.2 Contrôle

Avant validation :

- vérification de la correspondance entre affirmations et sources qualifiées,
- cohérence avec le niveau de preuve mobilisé,
- absence d’ajout implicite ou de glissement interprétatif.

---

### 6.3 Validation

La validation finale du document est :

- exclusivement humaine,
- pleinement assumée par l’auteur,
- indépendante de tout outil d’IA.

---

## 7. Traçabilité minimale recommandée

Chaque document produit avec assistance IA devrait pouvoir indiquer :

- la version du cadre utilisée (V0),
- les sources mobilisées (IDs),
- la nature de l’assistance IA (reformulation, structuration, etc.).

Cette traçabilité peut être explicite ou conservée dans les versions de travail.

---

## 8. Portabilité et multi-environnement

Ce workflow est conçu pour :

- un usage sur Android, iOS et Windows,
- différents outils d’IA (ChatGPT ou autres),
- une alternance mobile / poste de travail.

Le respect du cadre ne dépend pas de l’outil,
mais de la discipline méthodologique.

---

## 9. Relation avec le workflow initial

Ce document constitue une **adaptation opérationnelle (V0.1)**.

- Le workflow initial demeure valide comme description générale.
- La présente version précise les conditions d’usage réel.
- Aucun impact normatif n’est introduit.

---

## Clause de clôture

L’usage de l’IA n’est ni nié ni centralisé.  
Il est reconnu, limité et intégré dans une chaîne de responsabilité humaine.

Le non-respect de ces principes invalide l’usage du cadre,
indépendamment de la qualité apparente du résultat.