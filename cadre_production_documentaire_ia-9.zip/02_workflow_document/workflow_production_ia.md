# Workflow de production documentaire assistée par IA

## 1. Objet du document

Le présent document décrit le **workflow opérationnel** de production documentaire assistée par intelligence artificielle, fondé sur le cadre de qualification des sources **V0**.

Il ne définit aucune règle nouvelle.
Il explicite la manière dont :
- le cadre figé,
- la doctrine associée,
- et l’IA

s’articulent dans un processus de production maîtrisé.

---

## 2. Principe général du workflow

Le workflow repose sur une séquence **obligatoire et non contournable** en trois étapes :

1. **Qualification des sources** (humaine, normative)
2. **Production documentaire assistée par IA** (sous contrainte)
3. **Validation et gouvernance** (humaine, institutionnelle)

Aucune étape ne peut être sautée ou fusionnée.

---

## 3. Étape 1 — Qualification des sources (préalable obligatoire)

### 3.1 Objectif

Établir un **registre de sources qualifiées**, conforme au cadre normatif V0, avant toute production documentaire.

### 3.2 Référence normative

Cette étape est intégralement régie par :

- `01_cadre_fige/cadre_sources_V0.html`

Aucune production assistée par IA n’est autorisée tant que cette étape n’est pas achevée.

### 3.3 Résultat attendu

- Un tableau de sources complété
- Des sources qualifiées, hiérarchisées et traçables
- Une version du cadre explicitement référencée (V0)

---

## 4. Étape 2 — Production documentaire assistée par IA (sous contrainte)

### 4.1 Rôle de l’IA

Dans ce workflow, l’IA intervient exclusivement comme :

- outil de rédaction,
- outil de structuration,
- outil de reformulation.

L’IA :
- ne choisit pas les sources,
- ne les qualifie pas,
- ne modifie ni leur niveau de preuve ni leur priorité.

---

### 4.2 Entrées fournies à l’IA

Toute sollicitation de l’IA doit expliciter a minima :

- la **version du cadre utilisée** (ex. V0),
- la **liste des sources mobilisées** (IDs),
- le **niveau de preuve minimal autorisé**,
- le **type de document attendu** (note, synthèse, cadrage, etc.).

---

### 4.3 Exemple de formulation d’appel à l’IA

> Produire une synthèse factuelle en s’appuyant exclusivement sur les sources S02, S05 et S08, qualifiées niveau de preuve modéré ou élevé dans le cadre V0.  
> Aucune recommandation ni extrapolation ne doit être formulée.

Ces formulations sont indicatives et non figées.

---

### 4.4 Traçabilité minimale

Chaque document produit avec assistance IA doit pouvoir documenter :

- les sources utilisées,
- la version du cadre de référence,
- le rôle attribué à l’IA,
- les limites identifiées liées au niveau de preuve.

---

## 5. Étape 3 — Validation et gouvernance documentaire

### 5.1 Principe de responsabilité

La validation finale d’un document est **exclusivement humaine**.

L’IA ne valide rien.
Elle ne porte aucune responsabilité institutionnelle.

---

### 5.2 Actions de validation

Avant diffusion ou archivage :

- relecture humaine obligatoire,
- vérification de la conformité au cadre V0,
- contrôle de la cohérence entre sources et contenu produit.

---

### 5.3 Archivage

Les documents validés peuvent être :

- déposés dans une GED (ex. SharePoint),
- versionnés selon les règles institutionnelles,
- référencés comme *documents produits sous cadre V0*.

Les métadonnées de la GED décrivent le document, non le raisonnement.

---

## 6. Cas d’usage typiques

Le workflow est adapté à la production de :

- notes analytiques,
- synthèses factuelles,
- documents de cadrage,
- rapports intermédiaires,
- documents préparatoires à la décision.

Il n’est pas conçu pour produire des décisions ou recommandations finales.

---

## 7. Usages exclus

Le workflow ne permet pas :

- l’usage de sources non qualifiées,
- la génération autonome de bibliographies,
- la délégation de l’analyse à l’IA,
- la validation automatique de contenus.

Tout usage hors de ce cadre est réputé **non conforme**.

---

## 8. Articulation avec le cadre et la doctrine

Ce workflow :

- applique le cadre normatif sans le modifier,
- s’inscrit dans la doctrine V0,
- peut évoluer indépendamment du cadre par ajustement opérationnel.

Toute évolution du workflow ne constitue pas une évolution du cadre.

---

## 9. Statut du document

Le présent document est un **document opératoire**.

Il peut être :
- adapté,
- enrichi,
- décliné

sans modification du cadre normatif ou de la doctrine associée.

---

## Clause de clôture

Toute production documentaire assistée par IA est réputée conforme uniquement si l’ensemble des trois étapes du présent workflow est respecté.

Le non-respect du workflow invalide l’usage du cadre.<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Workflow – Production documentaire assistée par IA</title>
</head>
<body>

<h1>Production documentaire assistée par IA</h1>

<h2>Étape 1 — Cadre de référence (figé)</h2>
<p>Référence obligatoire au cadre des sources.</p>

<h2>Étape 2 — Production assistée par IA</h2>
<p>IA utilisée sous contrainte du registre des sources.</p>

<h2>Étape 3 — Validation et archivage</h2>
<p>Validation humaine et gouvernance documentaire.</p>

</body>
</html>
