# Journal des versions — Cadre de production documentaire

## Historique des versions

| Version | Date | Élément concerné | Description | Justification |
|--------|------|------------------|-------------|---------------|
| V0 | 2026-02-01 | Cadre des sources + Doctrine | Création du cadre normatif figé (`cadre_sources_V0.html`) et de la Doctrine V0 associée (`doctrine_et_usages.md`). Définition du point zéro méthodologique pour la qualification des sources et l’usage en production documentaire assistée par IA. | Établissement d’un cadre de départ de recherche stable, traçable et non rétroactif. |

---

## Règles de gestion des versions

- Chaque version est **figée**.
- Aucune modification implicite n’est autorisée.
- Toute évolution du cadre ou de la doctrine :
  - donne lieu à une **nouvelle version**,
  - est **explicitement justifiée**,
  - n’a **aucun effet rétroactif**.
- Les documents produits doivent toujours référencer explicitement la **version du cadre et de la doctrine utilisés**.

---

## Portée

Ce journal constitue la référence officielle pour :
- l’identification des versions applicables,
- la traçabilité méthodologique,
- la lisibilité institutionnelle dans le temps.

Toute version non consignée dans ce journal est réputée **inexistante**.