# Doctrine et usages

Ce document décrit l’articulation entre :
- le cadre figé,
- les outils existants (Zotero, SharePoint),
- et l’usage de l’IA.



---

Doctrine et usages — V0

Qualification institutionnelle des sources et usage en production documentaire assistée par IA


---

1. Statut de la doctrine

La présente doctrine définit les principes d’usage, les règles d’articulation et les limites d’interprétation du cadre de qualification des sources V0.

Elle est indissociable du document normatif suivant :

> 01_cadre_fige/cadre_sources_V0.html



La doctrine V0 :

n’ajoute aucune règle au cadre,

n’en modifie aucune,

en explicite la portée institutionnelle et opérationnelle.



---

2. Finalité du cadre V0

Le cadre V0 a pour finalité de constituer un registre de qualification des sources permettant :

une lecture scientifique rigoureuse,

une utilisation institutionnelle maîtrisée,

une production documentaire traçable,

et un usage contrôlé des outils d’intelligence artificielle.


Il ne vise ni la production de connaissances nouvelles,
ni la prise de décision,
ni la validation de conclusions.


---

3. Définition institutionnelle d’une source

Dans le cadre V0, une source est entendue comme :

> une publication identifiable, stable et vérifiable, produite par un auteur ou une entité clairement identifiée, et susceptible de fonder un raisonnement ou une analyse.



Ne constituent pas des sources au sens du cadre :

les opinions non référencées,

les synthèses secondaires non sourcées,

les contenus générés sans publication identifiable.



---

4. Principe cardinal : qualification avant usage

Le cadre V0 repose sur un principe non dérogatoire :

> Toute source doit être qualifiée avant tout usage analytique, rédactionnel ou décisionnel.



Ce principe s’applique :

indépendamment de l’autorité perçue de la source,

indépendamment de l’évidence apparente du contenu,

indépendamment de l’outil utilisé pour la production documentaire.


Aucun outil, y compris une IA, ne peut se substituer à cette qualification.


---

5. Séparation stricte des niveaux de sens

La doctrine V0 impose une séparation explicite entre :

1. Le contenu factuel de la source


2. Son apport spécifique à une problématique donnée


3. Les usages envisageables de cette source


4. Les conclusions ou décisions finales



Le cadre V0 s’arrête strictement au troisième niveau.
Toute confusion entre ces niveaux est considérée comme une dérive méthodologique.


---

6. Niveau de preuve et neutralité institutionnelle

Le niveau de preuve attribué à une source :

reflète exclusivement sa nature méthodologique,

ne constitue ni une validation scientifique absolue,

ni une prise de position institutionnelle.


Le cadre V0 qualifie la robustesse, non la vérité.

Cette neutralité est intentionnelle et structurante.


---

7. Priorité : logique d’usage, non de hiérarchie scientifique

La priorité attribuée à une source :

exprime son utilité fonctionnelle dans un contexte donné,

tient compte de sa robustesse et de sa pertinence,

ne constitue pas une hiérarchie de valeur scientifique.


La priorité est contextuelle et révisable par changement de contexte,
non par modification du cadre.


---

8. Langue, versions et traçabilité

La doctrine V0 impose une traçabilité complète des sources, incluant :

la langue de la version effectivement analysée (ISO 639-1),

la distinction entre versions linguistiques,

l’identification explicite de la version utilisée.


Toute production ultérieure doit pouvoir répondre sans ambiguïté à la question :

> « Quelle version exacte de quelle source fonde ce contenu ? »




---

9. Articulation avec les outils existants

Le cadre V0 ne se substitue pas :

aux outils bibliographiques (ex. Zotero),

aux systèmes de gestion documentaire (ex. SharePoint),

aux outils de production rédactionnelle.


Il se situe en amont, comme dispositif de qualification intellectuelle.

Les outils :

stockent,

citent,

transportent.


Le cadre :

structure le sens,

hiérarchise l’usage,

fonde la traçabilité méthodologique.



---

10. Usage du cadre en contexte IA

Dans un contexte de production documentaire assistée par IA :

l’IA ne qualifie pas les sources,

l’IA ne modifie pas leur statut,

l’IA n’introduit aucune source hors cadre.


L’IA intervient exclusivement :

après qualification humaine,

sous contrainte explicite du cadre,

comme outil de rédaction, de structuration ou de reformulation.



---

11. Statut V0 et évolution du cadre

Le cadre et la doctrine V0 constituent un point zéro méthodologique.

Ils peuvent évoluer par versions ultérieures, à condition que :

chaque version soit explicitement identifiée,

chaque évolution soit justifiée,

aucune modification ne soit rétroactive.


Chaque version est réputée figée entre deux évolutions.


---

Clause de clôture

La présente doctrine V0 définit les conditions de légitimité de toute production documentaire fondée sur des sources qualifiées.

Elle ne prescrit aucune conclusion,
mais conditionne la validité méthodologique des usages qui en découlent.


---

✅ État

Cadre : V0 figé

Doctrine : V0 alignée
